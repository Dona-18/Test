import csv
from datetime import datetime

products = []
sales = [] 
def seed_products():
    sample = [
        ("Paracetamol 500mg", "Analgesics", 100, 2.50),
        ("Amoxicillin 500mg", "Antibiotics", 50, 8.00),
        ("Cetirizine 10mg", "Antihistamines", 80, 5.00)
    ]
    next_id = 1
    for name, cat, qty, price in sample:
        products.append({'id': next_id, 'name': name, 'category': cat, 'qty': qty, 'price': price})
        next_id += 1

# -----------------------
# helpers
# -----------------------
def format_currency(x):
    return f"${x:,.2f}"

def find_product_by_id(pid):
    for p in products:
        if p['id'] == pid:
            return p
    return None

def next_product_id():
    return max((p['id'] for p in products), default=0) + 1

def generate_invoice():
    return f"INV-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

# -----------------------
# Product
# -----------------------
def list_products():
    if not products:
        print("No products available.")
        return
    print("\n\tID | Name (Category) — Qty — Price")
    print("=" * 50)
    for p in products:
        print(f"{p['id']:2d} | {p['name']} ({p['category']}) — {p['qty']} — {format_currency(p['price'])}")
    print("=" * 50)

def add_product():
    print("=" * 40)
    print("\nAdd new product")
    print("=" * 40)
    name = input("Name: ").strip()
    if not name:
        print("Name cannot be empty.")
        return
    category = input("Category: ").strip() or "Uncategorized"
    try:
        qty = int(input("Quantity (integer): ").strip())
        price = float(input("Price (e.g. 9.99): $").strip())
    except ValueError:
        print("Invalid number input. Aborting add.")
        return
    pid = next_product_id()
    products.append({'id': pid, 'name': name, 'category': category, 'qty': qty, 'price': price})
    print(f"Product added with ID {pid}.\n")

def edit_product():
    list_products()
    try:
        pid = int(input("Enter product ID to edit: ").strip())
    except ValueError:
        print("Invalid ID.")
        return
    p = find_product_by_id(pid)
    if not p:
        print("Product not found.")
        return
    print(f"Editing {p['name']} (leave blank to keep current)")
    name = input(f"Name [{p['name']}]: ").strip() or p['name']
    category = input(f"Category [{p['category']}]: ").strip() or p['category']
    qty_input = input(f"Quantity [{p['qty']}]: ").strip()
    price_input = input(f"Price [{p['price']}]: ").strip()
    try:
        qty = int(qty_input) if qty_input else p['qty']
        price = float(price_input) if price_input else p['price']
    except ValueError:
        print("Invalid number. Changes not saved.")
        return
    p.update({'name': name, 'category': category, 'qty': qty, 'price': price})
    print("Product updated.\n")

def delete_product():
    try:
        pid = int(input("Enter product ID to delete: ").strip())
    except ValueError:
        print("Invalid ID.")
        return
    p = find_product_by_id(pid)
    if not p:
        print("Product not found.")
        return
    confirm = input(f"Are you sure you want to delete '{p['name']}'? (y/N): ").strip().lower()
    if confirm == 'y':
        products.remove(p)
        print("Product deleted.")
    else:
        print("Deletion cancelled.")

# -----------------------
# Sales
# -----------------------
def process_sale():
    if not products:
        print("No products to sell.")
        return
    cart = []
    while True:
        list_products()
        entry = input("Enter product ID to add (or 'done' to finish): ").strip()
        if entry.lower() == 'done':
            break
        try:
            pid = int(entry)
        except ValueError:
            print("Invalid ID.")
            continue
        p = find_product_by_id(pid)
        if not p:
            print("Product not found.")
            continue
        try:
            qty = int(input(f"Quantity for {p['name']} (available {p['qty']}): ").strip())
        except ValueError:
            print("Invalid quantity.")
            continue
        if qty <= 0:
            print("Quantity must be positive.")
            continue
        if qty > p['qty']:
            print("Not enough stock.")
            continue
        cart.append({'product_id': pid, 'name': p['name'], 'qty': qty, 'unit_price': p['price']})
        print(f"Added {qty} x {p['name']} to cart.\n")

    if not cart:
        print("Cart is empty; sale cancelled.")
        return

    # Show receipt
    print("\n--- Receipt ---")
    total = 0
    for item in cart:
        line = item['qty'] * item['unit_price']
        total += line
        print(f"{item['name']}: {item['qty']} x {format_currency(item['unit_price'])} = {format_currency(line)}")
    print(f"Total: {format_currency(total)}")
    confirm = input("Complete sale? (y/N): ").strip().lower()
    if confirm != 'y':
        print("Sale cancelled.")
        return

    # Deduct stock and record sale
    for item in cart:
        p = find_product_by_id(item['product_id'])
        p['qty'] -= item['qty']
    invoice = generate_invoice()
    sales.append({'invoice': invoice, 'items': cart, 'total': total, 'time': datetime.now().isoformat()})
    print(f"Sale complete. Invoice: {invoice}\n")

def view_sales():
    if not sales:
        print("No sales recorded.")
        return
    print("\nRecent sales:")
    for s in sales[-10:]:
        print(f"Invoice {s['invoice']} — {s['time']} — Total {format_currency(s['total'])}")
        names = ", ".join([f"{it['qty']}x {it['name']}" for it in s['items']])
        print("  Items:", names)
    print()

def export_products_csv(filename="products_export.csv"):
    try:
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['id', 'name', 'category', 'qty', 'price'])
            for p in products:
                writer.writerow([p['id'], p['name'], p['category'], p['qty'], p['price']])
        print(f"Products exported to {filename}")
    except Exception as e:
        print("Export failed:", e)

# -----------------------
# Simple login
# -----------------------
ADMIN_PASSWORD = "admin123"

def admin_menu():
    while True:
        print("=" * 40)
        print("\t\tAdmin Menu")
        print("=" * 40)
        print("1) List products")
        print("2) Add product")
        print("3) Edit product")
        print("4) Delete product")
        print("5) View sales")
        print("6) Export products to CSV")
        print("0) Back to main")
        print("=" * 40)
        choice = input("Choose: ").strip()
        print("=" * 40)
        if choice == '1':
            list_products()
        elif choice == '2':
            add_product()
        elif choice == '3':
            edit_product()
        elif choice == '4':
            delete_product()
        elif choice == '5':
            view_sales()
        elif choice == '6':
            export_products_csv()
        elif choice == '0':
            break
        else:
            print("Unknown choice.")

# -----------------------
# Main program loop
# -----------------------
seed_products()
print("Simple Pharmacy Manager (Beginner version)")
while True:
    print("\n")
    print("=" * 40)
    print("\t\tMain Menu:")
    print("=" * 40)
    print("1) List products")
    print("2) Sell products (process sale)")
    print("3) View recent sales")
    print("4) Admin login")
    print("0) Quit")
    print("=" * 40)
    choice = input("Choose: ").strip()
    if choice == '1':
        list_products()
    elif choice == '2':
        process_sale()
    elif choice == '3':
        view_sales()
    elif choice == '4':
        pw = input("Admin password: ").strip()
        if pw == ADMIN_PASSWORD:
            print("Welcome, admin.")
            admin_menu()
        else:
            print("Wrong password.")
    elif choice == '0':
            print("Goodbye.")
            break
    else:
        print("Unknown option. Try again.")


